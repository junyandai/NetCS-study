# TOB-QMC-3f1a Estimated Trees of Blobs

This directory contains trees of blobs (TOBs) estimated by the
**TOB-QMC-3f1a** procedure for the CAMUS simulation data set.

## Directory structure

Files are organized by CAMUS taxon condition and replicate:

```text
TOB-QMC-3f1a/
├── n50/
│   ├── 00/TOB-QMC-3f1a_ASTRAL_n50_network_00_alpha1e-4_beta1.00.tob
│   └── ...
├── n100/
│   └── ...
├── n150/
│   └── ...
└── n200/
│   └── ...
│ 
└── TOB-QMC-3f1a-CAMUS-dataset.csv
│
└── TOB-QMC-3f1a-CAMUS-dataset-filter-out-4-blob.csv