# TOB-QMC Parameter Tuning

This directory contains the trees of blobs generated during the
TOB-QMC parameter-tuning study on the CAMUS simulation data.

The tuning study evaluates different values of the TOB-QMC hyperparameters
and includes results from both:

```text
TOB-QMC-3f1a
TOB-QMC-default
```

### Turning experiment results
The turning experiment results are included in ```TOB-QMC-3f1a-tuning-CAMUS-dataset.csv```.
The derived draft analysis figure is included in ```figure5-draft.pdf```.
The final figure appearing in the paper may differ slightly in visual
presentation because it may be manually edited in Adobe Illustrator for
publication. Any such edits are only limited to cosmetic layout adjustments; the underlying data and numerical
results are unchanged.

